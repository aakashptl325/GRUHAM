import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServicemapService {
  
  constructor(private http:HttpClient) { }

  addCategory(serv)
  {
    return this.http.post("http://localhost:8080/addCategory",serv,{responseType:'text' as 'json'});
  }
}

import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AgencyworkerhomeComponent } from './agencyworkerhome/agencyworkerhome.component';
import { AgencyworkerregisterComponent } from './agencyworkerregister/agencyworkerregister.component';
import { CustomerOrderComponent } from './customer-order/customer-order.component';
import { CustomerhomeComponent } from './customerhome/customerhome.component';
import { CustomerlistComponent } from './customerlist/customerlist.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { OrderService } from './order.service';
import { ProviderlistComponent } from './providerlist/providerlist.component';
import { RegisterComponent } from './register/register.component';
import { ServicemapComponent } from './servicemap/servicemap.component';
import { ShowcustomerComponent } from './showcustomer/showcustomer.component';
import { ShowservicebyprovidertypeComponent } from './showservicebyprovidertype/showservicebyprovidertype.component';
import { ShowservicesComponent } from './showservices/showservices.component';

const routes: Routes = [
{path:'',component:HomeComponent},
{path:'agencyworkerhome',component:AgencyworkerhomeComponent},
{path:'login',component:LoginComponent},
{path:'register',component:RegisterComponent},
{path:'agencyworkerregister',component:AgencyworkerregisterComponent},
{path:'customerhome',component:CustomerhomeComponent},
{path:'adminhome',component:AdminhomeComponent},
{path:'adminlogin',component:AdminloginComponent},
{path:'showorders',component:CustomerOrderComponent},
{path:'servicemap',component:ServicemapComponent},
{path:'showservices',component:ShowservicesComponent},
{path:'showcustomer',component:ShowcustomerComponent},
{path:'customerlist',component:CustomerlistComponent},
{path:'providerlist',component:ProviderlistComponent},
{path:'showservicebyprovidertype',component:ShowservicebyprovidertypeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
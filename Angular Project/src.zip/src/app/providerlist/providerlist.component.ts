import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminserviceService } from '../adminservice.service';

@Component({
  selector: 'app-providerlist',
  templateUrl: './providerlist.component.html',
  styleUrls: ['./providerlist.component.scss']
})
export class ProviderlistComponent implements OnInit {

  provider:any;
  id:string;
  constructor(private a : AdminserviceService,private route :Router) { }

  ngOnInit(): void {
    this.a.getproviderlist().subscribe((x)=>{this.provider=x});
//    this.id=localStorage.getItem('token');
  }
  adminhome()
  {
    this.route.navigate(['adminhome'])
  }
  showcustomer()
  {
    this.route.navigate(['customerlist'])
  }
  showprovider()
  {
    this.route.navigate(['providerlist'])
  }
  logOut()
  {
    sessionStorage.clear();
    this.route.navigate([''])
  }
}

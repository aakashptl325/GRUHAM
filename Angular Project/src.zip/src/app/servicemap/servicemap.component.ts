import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicemap',
  templateUrl: './servicemap.component.html',
  styleUrls: ['./servicemap.component.scss']
})
export class ServicemapComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}
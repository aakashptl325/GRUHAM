import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServicemapComponent } from './servicemap.component';

describe('ServicemapComponent', () => {
  let component: ServicemapComponent;
  let fixture: ComponentFixture<ServicemapComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ServicemapComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ServicemapComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { CustomerOrder } from "./CustomerOrder";
import { ServiceProvider } from "./ServiceProvider";

export class Showservicebyprovidertype
{
    constructor(public customer_Type?:String,public type_Name?: String,public cust?:ServiceProvider[],public customer?:CustomerOrder[])
    {

    }
}
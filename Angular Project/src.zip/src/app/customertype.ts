import { Customer } from "./customer";
import { ServiceProvider } from "./ServiceProvider";

export class CustomerType
{
    constructor(public customer_Type?:string,public type_Name?:string)
    {

    }
}
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminserviceService } from '../adminservice.service';

@Component({
  selector: 'app-customerlist',
  templateUrl: './customerlist.component.html',
  styleUrls: ['./customerlist.component.scss']
})
export class CustomerlistComponent implements OnInit {

  Cust:any;
  id:string;
  constructor(private a : AdminserviceService,private route :Router) { }

  ngOnInit(): void {
    this.a.getcustomerlist().subscribe((x)=>{this.Cust=x});
//    this.id=localStorage.getItem('token');
  }
  adminhome()
  {
    this.route.navigate(['adminhome'])
  }
  showcustomer()
  {
    this.route.navigate(['customerlist'])
  }
  showprovider()
  {
    this.route.navigate(['providerlist'])
  }
  logOut()
  {
    sessionStorage.clear();
    this.route.navigate([''])
  }
}

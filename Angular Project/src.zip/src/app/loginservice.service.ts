import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class LoginserviceService {

  constructor(private http:HttpClient) { }

  public doLoginascustomer(userid,pwd){
  
    //console.log('inside ', requestData)
    return this.http.get("http://localhost:8080/login?username="+userid+"&password="+pwd);
  }

  public doLoginasservice(userid,pwd){
  
    //console.log('inside ', requestData)
    return this.http.get("http://localhost:8080/loginServiceProvider?username="+userid+"&password="+pwd);
  }

  public doLoginasadmin(userid,pwd){
  
    //console.log('inside ', requestData)
    return this.http.get("http://localhost:8080/loginAdmin?username="+userid+"&password="+pwd);
  }
}

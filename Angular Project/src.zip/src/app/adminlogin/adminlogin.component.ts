import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginserviceService } from '../loginservice.service';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './adminlogin.component.html',
  styleUrls: ['./adminlogin.component.scss']
})
export class AdminloginComponent implements OnInit {

    loginForm: FormGroup = this.formBuilder.group({
   
    user_id: ['', Validators.required],
    password: ['', Validators.required]
});

  isSubmitted = false;
  userid=''
  password='';
  
  constructor(private admin:LoginserviceService,private formBuilder: FormBuilder,private route :Router) { }

  ngOnInit(): void {
  }

  home()
  {
    this.route.navigate([''])
  }

  public loginasadmin(){
    this.isSubmitted = true;

    let uid=this.loginForm.controls["user_id"].value;
    let pwd=this.loginForm.controls["password"].value;

    this.admin.doLoginasadmin(uid,pwd).subscribe(data=>{
      if(data!=null)
      {
        sessionStorage.setItem('isLogin',"true");
        sessionStorage.setItem('token',JSON.stringify(data));
        this.route.navigate(['adminhome'])
       /* localStorage.setItem(key, data.toString());
        */
      }
      else{
        alert("User Id or Password is incorrect!!!")
      }
    }
    );
  }
}
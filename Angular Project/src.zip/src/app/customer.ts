import { CustomerType } from "./customertype";

export class Customer
{
    constructor(public first_name?:string,public last_name?:string,public email?:string,public password?:string,public contact?:String,public address_line1?:string,public address_line2?:string,public city?:string,public pincode?:string,public custType?:CustomerType,public user_id?:string, public cid?:number)
    {

    }
}
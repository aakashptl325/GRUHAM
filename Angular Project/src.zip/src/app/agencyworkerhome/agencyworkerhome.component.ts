import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AgencyworkerhomeService } from '../agencyworkerhome.service';
import { ServiceProviderService } from '../service-provider.service';
import { ServiceProvider } from '../ServiceProvider';

@Component({
  selector: 'app-agencyworkerhome',
  templateUrl: './agencyworkerhome.component.html',
  styleUrls: ['./agencyworkerhome.component.scss']
})
export class AgencyworkerhomeComponent implements OnInit {

  Provider:ServiceProvider=new ServiceProvider();
  
  constructor(private service:ServiceProviderService,private route:Router) { }
  ngOnInit(): void {
    this.Provider=JSON.parse(sessionStorage.getItem("token"));
  }

  getproviderinfo(spid: any)
  {
    this.service.getProvider(spid).subscribe((x)=>{this.Provider = x});
  }



  agencyhome()
  {
    this.route.navigate(['agencyworkerhome'])
  }
  showservices()
  {
    this.route.navigate(['showservices'])
  }
  showcustomer()
  {
    this.route.navigate(['showcustomer'])
  }
  logOut()
  {
    sessionStorage.clear();
    this.route.navigate([''])
  }
}

import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyworkerhomeComponent } from './agencyworkerhome.component';

describe('AgencyworkerhomeComponent', () => {
  let component: AgencyworkerhomeComponent;
  let fixture: ComponentFixture<AgencyworkerhomeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgencyworkerhomeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AgencyworkerhomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

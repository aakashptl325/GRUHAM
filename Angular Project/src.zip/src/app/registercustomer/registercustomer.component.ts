import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, PatternValidator, Validators } from '@angular/forms';
import { Customer } from '../customer';
import { RegisterserviceService } from '../registerservice.service';

@Component({
  selector: 'app-registercustomer',
  templateUrl: './registercustomer.component.html',
  styleUrls: ['./registercustomer.component.scss']
})
export class RegistercustomerComponent implements OnInit {

    user=new Customer();

    private _customerForm: FormGroup = new FormGroup({
    first_name: new FormControl('', Validators.required),
    last_name: new FormControl('', Validators.required),
    email: new FormControl('', Validators.required),
    password: new FormControl('', Validators.required),
    contact: new FormControl('', Validators.required),
    address_line1: new FormControl('', Validators.required),
    address_line2: new FormControl('', Validators.required),
    city: new FormControl('', Validators.required),
    pincode: new FormControl('', Validators.required),
    user_id: new FormControl('', Validators.required)
  });
  
  message:any;
  isSubmitted = false;
  FormBuilder: any;
  
  constructor(private regservice:RegisterserviceService) { }

  customerForm = new FormGroup({
    first_name: new FormControl(''),
    last_name: new FormControl(''),
  });

  ngOnInit(): void {
  }

  
  public registerNow(){
    this.isSubmitted = true;

    console.log(this.customerForm);
    this.regservice.doRegistration(this.customerForm.value).subscribe(data=>{
        if(data!=null)
        {
          alert("Registered succsessfully")
        }
        else{
          alert("Not Registered Please enter correctly")
        }
      }
    );
  }
}

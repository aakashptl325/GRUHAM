import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerhomeService } from '../customerhome.service';
import { CustomerOrder } from '../CustomerOrder';

@Component({
  selector: 'app-customerhome',
  templateUrl: './customerhome.component.html',
  styleUrls: ['./customerhome.component.scss']
})
export class CustomerhomeComponent implements OnInit {

  Cust:CustomerOrder=new CustomerOrder();
  id:string;
  constructor(private cservice : CustomerhomeService,private route :Router) { }

  ngOnInit(): void {
    this.Cust=JSON.parse(sessionStorage.getItem("token"));
//    this.id=localStorage.getItem('token');
  }
  showbytype()
  {
    this.route.navigate(['showservicebyprovidertype'])
  }
  getinfo(cid)
  {
    this.cservice.getCustomer(cid).subscribe((x)=>{this.Cust = x});
  }
  logOut()
  {
    sessionStorage.clear();
    this.route.navigate([''])
  }
}

import { TestBed } from '@angular/core/testing';

import { AgencyworkerhomeService } from './agencyworkerhome.service';

describe('AgencyworkerhomeService', () => {
  let service: AgencyworkerhomeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(AgencyworkerhomeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

import { Order } from "./order";
import { Showservicebyprovidertype } from "./showservicebyprovidertype";

export class CustomerOrder
{
    constructor(public cid?:number, public first_name?:String, public last_name?:String, public email?:String, public password?:String, public contact?:String, public address_line1?:String, public address_line2?:String, public city?:String, public pincode?:String, public status?:number, public user_id?:String,public orders?:Order[], public custType?:Showservicebyprovidertype)
    {

    }
}
			
import { Category } from "./category";
import { ServiceProvider } from "./ServiceProvider";

export class Servicemap
{
    constructor(public price?:number, public service?:Category, public provider?:ServiceProvider, public map_id?:number)
    {
        
    }
}
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ServiceProviderService } from '../service-provider.service';
import { ServiceProvider } from '../ServiceProvider';

@Component({
  selector: 'app-showcustomer',
  templateUrl: './showcustomer.component.html',
  styleUrls: ['./showcustomer.component.scss']
})
export class ShowcustomerComponent implements OnInit {

  Provider:ServiceProvider=new ServiceProvider();
  
  constructor(private service:ServiceProviderService,private route:Router) { }
  ngOnInit(): void {
    this.Provider=JSON.parse(sessionStorage.getItem("token"));
  }

  getproviderinfo(spid: any)
  {
    this.service.getProvider(spid).subscribe((x)=>{this.Provider = x});
  }



  agencyhome()
  {
    this.route.navigate(['agencyworkerhome'])
  }
  showservices()
  {
    this.route.navigate(['showservices'])
  }
  showcustomer()
  {
    this.route.navigate(['showcustomer'])
  }
  logOut()
  {
    sessionStorage.clear();
    this.route.navigate([''])
  }
}

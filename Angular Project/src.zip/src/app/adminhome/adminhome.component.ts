import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Admin } from '../admin';
import { AdminserviceService } from '../adminservice.service';

@Component({
  selector: 'app-adminhome',
  templateUrl: './adminhome.component.html',
  styleUrls: ['./adminhome.component.scss']
})
export class AdminhomeComponent implements OnInit {

  admin:Admin=new Admin();
  id:string;
  constructor(private a : AdminserviceService,private route :Router) { }

  ngOnInit(): void {
    this.admin=JSON.parse(sessionStorage.getItem("token"));
//    this.id=localStorage.getItem('token');
  }

  adminhome()
  {
    this.route.navigate(['adminhome'])
  }
  showcustomer()
  {
    this.route.navigate(['customerlist'])
  }
  showprovider()
  {
    this.route.navigate(['providerlist'])
  }
  logOut()
  {
    sessionStorage.clear();
    this.route.navigate([''])
  }
}
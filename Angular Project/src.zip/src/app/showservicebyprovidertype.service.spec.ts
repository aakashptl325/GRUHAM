import { TestBed } from '@angular/core/testing';

import { ShowservicebyprovidertypeService } from './showservicebyprovidertype.service';

describe('ShowservicebyprovidertypeService', () => {
  let service: ShowservicebyprovidertypeService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ShowservicebyprovidertypeService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

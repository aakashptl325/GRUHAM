import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerOrderService } from '../customer-order.service';
import { CustomerhomeService } from '../customerhome.service';
import { CustomerOrder } from '../CustomerOrder';

@Component({
  selector: 'app-customer-order',
  templateUrl: './customer-order.component.html',
  styleUrls: ['./customer-order.component.scss']
})
export class CustomerOrderComponent implements OnInit {

  //Cust:Customer = new Customer();
  CustOrder:CustomerOrder = new CustomerOrder();
  
  id:string;
  constructor(private cservice : CustomerhomeService,private route :Router) { }

  ngOnInit(): void {
    this.CustOrder=JSON.parse(sessionStorage.getItem("token"));
//    this.id=localStorage.getItem('token');
//this.cservice.getCustomer(this.CustOrder.cid).subscribe((x)=>{this.CustOrder = x});
  }
  showbytype()
  {
    this.route.navigate(['showservicebyprovidertype'])
  }
  logOut()
  {
    sessionStorage.clear();
    this.route.navigate([''])
  }
}
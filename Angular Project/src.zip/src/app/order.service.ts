import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Order } from './order';

@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http:HttpClient) { }

  bookOrder(odr)
  {
    return this.http.post("http://localhost:8080/addOrder",odr,{responseType:'text' as 'json'});
  }
}

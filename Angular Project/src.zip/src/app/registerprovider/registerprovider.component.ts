import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registerprovider',
  templateUrl: './registerprovider.component.html',
  styleUrls: ['./registerprovider.component.scss']
})
export class RegisterproviderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

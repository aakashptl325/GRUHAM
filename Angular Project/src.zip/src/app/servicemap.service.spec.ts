import { TestBed } from '@angular/core/testing';

import { ServicemapService } from './servicemap.service';

describe('ServicemapService', () => {
  let service: ServicemapService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ServicemapService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});

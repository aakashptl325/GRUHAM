import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AgencyworkerhomeComponent } from './agencyworkerhome/agencyworkerhome.component';
import { ShowservicebyprovidertypeComponent } from './showservicebyprovidertype/showservicebyprovidertype.component';
import { ServiceProviderComponent } from './service-provider/service-provider.component';
import { OrderComponent } from './order/order.component';
import { ServicemapComponent } from './servicemap/servicemap.component';
import { CategoryComponent } from './category/category.component';
import { LoginComponent } from './login/login.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { CustomerhomeComponent } from './customerhome/customerhome.component';
import { RegisterproviderComponent } from './registerprovider/registerprovider.component';
import { AgencyworkerregisterComponent } from './agencyworkerregister/agencyworkerregister.component';
import { AdminloginComponent } from './adminlogin/adminlogin.component';
import { AdminhomeComponent } from './adminhome/adminhome.component';
import { CustomerOrderComponent } from './customer-order/customer-order.component';
import { ProviderlistComponent } from './providerlist/providerlist.component';
import { CustomerlistComponent } from './customerlist/customerlist.component';
import { ShowcustomerComponent } from './showcustomer/showcustomer.component';
import { ShowservicesComponent } from './showservices/showservices.component';

@NgModule({
  declarations: [
    AppComponent,
    AgencyworkerhomeComponent,
    ShowservicebyprovidertypeComponent,
    ServiceProviderComponent,
    OrderComponent,
    CustomerhomeComponent,
    CustomerOrderComponent,
    ServicemapComponent,
    CategoryComponent,
    LoginComponent,
    RegisterComponent,
    HomeComponent,
    RegisterproviderComponent,
    AgencyworkerregisterComponent,
    AdminloginComponent,
    AdminhomeComponent,
    ProviderlistComponent,
    CustomerlistComponent,
    ShowcustomerComponent,
    ShowservicesComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
  
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

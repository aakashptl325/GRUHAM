import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ShowservicebyprovidertypeService {

  constructor(private http:HttpClient) { }

  getServices(type)
  {
    return this.http.get("http://localhost:8080/getCustType?id="+type);
  }
}

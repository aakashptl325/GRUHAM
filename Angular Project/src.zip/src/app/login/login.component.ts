import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { LoginserviceService } from '../loginservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup = this.formBuilder.group({
   
    user_id: ['', Validators.required],
    password: ['', Validators.required]
});
  message:any;
  isSubmitted = false;
  userid=''
  password='';
  
  constructor(private userservice:LoginserviceService,private formBuilder: FormBuilder,private route :Router) { }


  ngOnInit(): void {
  }

  home()
  {
    this.route.navigate([''])
  }

  registerascustomer()
  {
    this.route.navigate(['register'])
  }

  registeragencyworker()
  {
    this.route.navigate(['agencyworkerregister'])
  }


  public loginServiceprovider(){
    this.isSubmitted = true;
    //console.log(this.loginForm);
    // let userid=this.loginForm.controls["username"].value;
    // let pwd=this.loginForm.controls["password"].value;
    // this.userservice.doLogin(userid,pwd).subscribe(
    //   (data)=>alert("Login successsful")
    //   );
//    let key = "ID";
    let uid=this.loginForm.controls["user_id"].value;
    let pwd=this.loginForm.controls["password"].value;

    this.userservice.doLoginasservice(uid,pwd).subscribe(data=>{
      if(data!=null)
      {
        sessionStorage.setItem('isLogin',"true");
        sessionStorage.setItem('token',JSON.stringify(data));
//        alert("Login succsessfull"),
        this.route.navigate(['agencyworkerhome'])
       /* localStorage.setItem(key, data.toString());
        */
      }
      else{
        alert("User Id or Password is incorrect!!!")
      }
    }
/*    error=>{}
  */  );
  }



  public loginNowascustomer(){
    this.isSubmitted = true;
    //console.log(this.loginForm);
    // let userid=this.loginForm.controls["username"].value;
    // let pwd=this.loginForm.controls["password"].value;
    // this.userservice.doLogin(userid,pwd).subscribe(
    //   (data)=>alert("Login successsful")
    //   );
//    let key = "ID";
    let uid=this.loginForm.controls["user_id"].value;
    let pwd=this.loginForm.controls["password"].value;

    this.userservice.doLoginascustomer(uid,pwd).subscribe(data=>{
      if(data!=null)
      {
        sessionStorage.setItem('isLogin',"true");
        sessionStorage.setItem('token',JSON.stringify(data));
//        alert("Login succsessfull"),
        this.route.navigate(['customerhome'])
      }
      else{
        alert("User Id or Password is incorrect!!!")
      }
    }
/*    error=>{}
  */  );
  }
/*
  public loginNowagencyworker(){
    this.isSubmitted = true;

    //console.log(this.loginForm);
    // let userid=this.loginForm.controls["username"].value;
    // let pwd=this.loginForm.controls["password"].value;
    // this.userservice.doLogin(userid,pwd).subscribe(
    //   (data)=>alert("Login successsful")
    //   );

    let uid=this.loginForm.controls["user_id"].value;
    let pwd=this.loginForm.controls["password"].value;

    this.userservice.doLoginasagencyworker(uid,pwd).subscribe((data)=>alert("Login succsessfull"),
    (error)=>alert("Exception!!!")
    );
  }
/*
  public loginNowadmin(){
    this.isSubmitted = true;

    //console.log(this.loginForm);
    // let userid=this.loginForm.controls["username"].value;
    // let pwd=this.loginForm.controls["password"].value;
    // this.userservice.doLogin(userid,pwd).subscribe(
    //   (data)=>alert("Login successsful")
    //   );

    let uid=this.loginForm.controls["user_id"].value;
    let pwd=this.loginForm.controls["password"].value;

    this.userservice.doLoginadmin(uid,pwd).subscribe((data)=>alert("Login succsessfull"));
  */
 }
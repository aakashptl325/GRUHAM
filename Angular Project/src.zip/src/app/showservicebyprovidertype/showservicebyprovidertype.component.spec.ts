import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowservicebyprovidertypeComponent } from './showservicebyprovidertype.component';

describe('ShowservicebyprovidertypeComponent', () => {
  let component: ShowservicebyprovidertypeComponent;
  let fixture: ComponentFixture<ShowservicebyprovidertypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ShowservicebyprovidertypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowservicebyprovidertypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

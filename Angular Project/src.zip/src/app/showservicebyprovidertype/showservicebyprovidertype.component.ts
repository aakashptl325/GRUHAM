import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CustomerOrderService } from '../customer-order.service';
import { Order } from '../order';
import { OrderService } from '../order.service';
import { ServiceProvider } from '../ServiceProvider';
import { Showservicebyprovidertype } from '../showservicebyprovidertype';
import { ShowservicebyprovidertypeService } from '../showservicebyprovidertype.service';

@Component({
  selector: 'app-showservicebyprovidertype',
  templateUrl: './showservicebyprovidertype.component.html',
  styleUrls: ['./showservicebyprovidertype.component.scss']
})
export class ShowservicebyprovidertypeComponent implements OnInit {

  Services:Showservicebyprovidertype=new Showservicebyprovidertype();
  od:Order=new Order();
  info:boolean=false;
  constructor(private cservice:ShowservicebyprovidertypeService,private odr:OrderService,private route:Router) { }

  ngOnInit(): void {
  }
  
  order(pr:ServiceProvider)
  {
    
    let amt = 0;
    //alert(pr.first_name);
    for(let i = 0; i < pr.servpro.length;i++)
    {
      amt += pr.servpro[i].price;
      // amt+=pr.servpro[i].price;
    }
      let o:Order=new Order(new Date(),amt,JSON.parse(sessionStorage.getItem("token")),pr);
      //console.log(o);
      // let o:Order=new Order(new Date(),amt,this.Custom,pr);
      
      this.odr.bookOrder(o).subscribe((x)=>{this.od = x});
//      alert(sessionStorage.getItem("token").toString());
       alert("Order Booked");
      this.route.navigate(['customerhome'])
  }
  getinfo(type)
  {
    this.info=true;
    this.cservice.getServices(type).subscribe((x)=>{this.Services = x});
  }
  showbytype()
  {
    this.route.navigate(['showservicebyprovidertype'])
  }
  logOut()
  {
    sessionStorage.clear();
    this.route.navigate([''])
  }
}
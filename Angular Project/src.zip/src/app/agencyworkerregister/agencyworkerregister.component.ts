import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AgencyWorker } from '../agencyworker';
import { CustomerType } from '../customertype';
import { RegisterserviceService } from '../registerservice.service';

@Component({
  selector: 'app-agencyworkerregister',
  templateUrl: './agencyworkerregister.component.html',
  styleUrls: ['./agencyworkerregister.component.scss']
})
export class AgencyworkerregisterComponent implements OnInit {

  type:CustomerType = new CustomerType();

  agwk:AgencyWorker = new AgencyWorker("","","","","","","","","",this.type,"");
  
  constructor(private regservice:RegisterserviceService, private route:Router) { }

  ngOnInit(): void {

  }

  home()
  {
    this.route.navigate([''])
  }

  login()
  {
    this.route.navigate(['login'])
  }

  addcustomerformsubmit(){
    if(this.agwk.custtype.customer_Type=="A")
    {
      this.type = new CustomerType("A","Agency");
      this.agwk.custtype = this.type;
      console.log(this.agwk);
      this.regservice.doServRegistration(this.agwk).subscribe( 
        data=>{
         this.route.navigate(['login'])
        },
        error=>{
          alert('Not Registered')
          console.log('Not Registered')
          this.route.navigate(['agencyworkerregister'])
      }
    )
    }
    else if(this.agwk.custtype.customer_Type=="W")
    {
      this.type = new CustomerType("W","Worker");
      this.agwk.custtype = this.type;
      console.log(this.agwk);
      this.regservice.doServRegistration(this.agwk).subscribe( 
        data=>{
          alert('data added successfully')
          console.log('data added successfully');
           this.route.navigate(['login'])
        },
        error=>{
          alert('details not added')
          console.log('details not added')
      }
    )
    } 
  }
}
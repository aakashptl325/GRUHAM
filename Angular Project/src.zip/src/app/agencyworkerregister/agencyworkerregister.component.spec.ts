import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AgencyworkerregisterComponent } from './agencyworkerregister.component';

describe('AgencyworkerregisterComponent', () => {
  let component: AgencyworkerregisterComponent;
  let fixture: ComponentFixture<AgencyworkerregisterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AgencyworkerregisterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AgencyworkerregisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

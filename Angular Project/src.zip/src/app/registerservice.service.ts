import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AgencyWorker } from './agencyworker';
import { Customer } from './customer';

@Injectable({
  providedIn: 'root'
})
export class RegisterserviceService {

  constructor(private http:HttpClient) { }

  public doRegistration(customer: Customer){
    return this.http.post("http://localhost:8080/addCustomer",customer,{responseType:'text' as 'json'});
  }

  public doServRegistration(agwk: AgencyWorker){
    return this.http.post("http://localhost:8080/addServiceProvider",agwk,{responseType:'text' as 'json'});
  }
}
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CustomerOrderService {

  constructor(private http:HttpClient) { }

  getCustomerOrders(cid)
  {
    return this.http.get("http://localhost:8080/getCustOrderById?id="+cid);
  }
}

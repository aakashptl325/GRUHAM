import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AdminserviceService {

  constructor(private http:HttpClient) { }

  getcustomerlist()
  {
    return this.http.get("http://localhost:8080/getCustList");
  }

  getproviderlist()
  {
    return this.http.get("http://localhost:8080/getServiceProviderList");
  }
}

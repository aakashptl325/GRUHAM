import { Servicemap } from "./servicemap";

export class Category
{
    constructor(public service_Id?:number,public service_Name?:String, public serv?:Servicemap[])
    {
        
    }
}
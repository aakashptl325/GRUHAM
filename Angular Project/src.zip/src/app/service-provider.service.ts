import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class ServiceProviderService {

  constructor(private http:HttpClient) { }

  getProvider(spid)
  {
    return this.http.get("http://localhost:8080/getProviderById?id="+spid);
  }
}
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Customer } from '../customer';
import { CustomerType } from '../customertype';
import { RegisterserviceService } from '../registerservice.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.scss']
})
export class RegisterComponent implements OnInit {

  
  type:CustomerType = new CustomerType();

  customer:Customer = new Customer("","","","","","","","","",this.type,"");
  
  constructor(private regservice:RegisterserviceService, private route:Router) { }

  ngOnInit(): void {

  }

  home()
  {
    this.route.navigate([''])
  }

  login()
  {
    this.route.navigate(['login'])
  }
  
  addcustomerformsubmit(){
    
      this.type = new CustomerType("E","End User");
      this.customer.custType = this.type;
      console.log(this.customer);
      this.regservice.doRegistration(this.customer).subscribe( 
        data=>{
           this.route.navigate(['login'])
        },
        error=>{
          alert('Not Registered')
          console.log('Not Registered')
          this.route.navigate(['register'])
      }
    )
  }

  // public registerNow(){
  //  this.isSubmitted = true;

    //console.log(this.customerForm);
    /*this.regservice.doRegistration(this.customerForm.value).subscribe(
      (data)=>alert("Registered successfully")
    );*/


  // }

}

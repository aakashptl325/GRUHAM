import { Customer } from "./customer";
import { CustomerOrder } from "./CustomerOrder";
import { ServiceProvider } from "./ServiceProvider";

export class Order
{
    constructor(public datetime?:Date, public total_price?:number, public custodr?:Customer, public odrpro?:ServiceProvider)
    {
        
    }
}